Please read https://arm-software.github.io/ComputeLibrary/latest/contribution_guidelines.xhtml

Here on github we only publish a snapshot of the main development branch for each release, that's the reason why we don't accept pull requests.

Please submit your patch for review to review.mlplatform.org.

The development is structured in the following way:

    Release repository: https://github.com/arm-software/ComputeLibrary
    Development repository: https://review.mlplatform.org/#/admin/projects/ml/ComputeLibrary
    Please report issues here: https://github.com/ARM-software/ComputeLibrary/issues
